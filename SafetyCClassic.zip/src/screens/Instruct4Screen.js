const instructImage = require('../assets/instruct4.png');

        <Image
          source={instructImage}
          style={styles.image}
          resizeMode="contain"
        /> 